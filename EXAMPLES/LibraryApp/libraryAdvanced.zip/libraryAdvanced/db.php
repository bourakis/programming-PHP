<?php
$conn = mysqli_connect('localhost','root','','library');

if(!$conn)
{
    die('Could not connect: ' . mysqli_error());
}
?>