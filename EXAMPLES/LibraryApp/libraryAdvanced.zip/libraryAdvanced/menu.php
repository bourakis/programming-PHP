<a href="index.php">Αρχική</a>
<a href="new.php">Νέα Εγγραφή</a>
<a href="list.php">Λίστα Βιβλίων</a>